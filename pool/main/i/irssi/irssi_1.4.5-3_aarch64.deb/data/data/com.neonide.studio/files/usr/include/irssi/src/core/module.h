#include <irssi/src/common.h>

#define MODULE_NAME "core"

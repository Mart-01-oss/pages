#include <irssi/src/common.h>
#include <irssi/src/irc/core/irc.h>

#define MODULE_NAME "fe-common/irc/notifylist"

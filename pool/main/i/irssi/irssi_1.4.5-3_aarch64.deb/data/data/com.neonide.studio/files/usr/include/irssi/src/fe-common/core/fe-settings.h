#ifndef IRSSI_FE_COMMON_CORE_FE_SETTINGS_H
#define IRSSI_FE_COMMON_CORE_FE_SETTINGS_H

void fe_settings_set_print(const char *key);

#endif

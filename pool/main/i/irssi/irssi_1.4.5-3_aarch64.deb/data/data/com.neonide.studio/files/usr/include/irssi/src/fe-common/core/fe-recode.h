#ifndef IRSSI_FE_COMMON_CORE_FE_RECODE_H
#define IRSSI_FE_COMMON_CORE_FE_RECODE_H

void fe_recode_init (void);
void fe_recode_deinit (void);

#endif /* IRSSI_FE_COMMON_CORE_FE_RECODE_H */

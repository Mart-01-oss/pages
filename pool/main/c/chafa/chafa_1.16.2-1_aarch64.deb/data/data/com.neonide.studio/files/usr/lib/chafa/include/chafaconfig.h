/* chafaconfig.h
 *
 * This is a generated file.  Please modify 'chafaconfig.h.in'. */

#ifndef __CHAFACONFIG_H__
#define __CHAFACONFIG_H__

G_BEGIN_DECLS

#define CHAFA_MAJOR_VERSION 1
#define CHAFA_MINOR_VERSION 16
#define CHAFA_MICRO_VERSION 2

G_END_DECLS

#endif /* __CHAFACONFIG_H__ */

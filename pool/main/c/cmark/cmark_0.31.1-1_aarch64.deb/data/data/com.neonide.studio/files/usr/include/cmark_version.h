#ifndef CMARK_VERSION_H
#define CMARK_VERSION_H

#define CMARK_VERSION ((0 << 16) | (31 << 8)  | 1)
#define CMARK_VERSION_STRING "0.31.1"

#endif

#!/data/data/com.neonide.studio/files/usr/bin/sh
export HISTFILE=$SHELL

// Copyright 2021 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "../data.h"

namespace openpgl
{
namespace cpp
{
/**
 * @brief
 *
 */
typedef PGLSampleData SampleData;

typedef PGLZeroValueSampleData ZeroValueSampleData;
}  // namespace cpp
}  // namespace openpgl
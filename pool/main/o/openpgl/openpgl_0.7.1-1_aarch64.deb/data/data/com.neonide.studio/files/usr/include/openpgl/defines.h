// Copyright 2024 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#pragma once

/* #undef OPENPGL_SUPPORT_DEVICE_TYPE_CPU_16 */
/* #undef OPENPGL_RADIANCE_CACHES */
/* #undef OPENPGL_IMAGE_SPACE_GUIDING_BUFFER */
/* #undef OPENPGL_DIRECTION_COMPRESSION */
/* #undef OPENPGL_RADIANCE_COMPRESSION */

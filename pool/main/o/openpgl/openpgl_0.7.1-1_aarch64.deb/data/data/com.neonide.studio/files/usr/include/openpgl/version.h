// Copyright 2021 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#pragma once

#define OPENPGL_VERSION_MAJOR 0
#define OPENPGL_VERSION_MINOR 7
#define OPENPGL_VERSION_PATCH 1
#define OPENPGL_VERSION "0.7.1"

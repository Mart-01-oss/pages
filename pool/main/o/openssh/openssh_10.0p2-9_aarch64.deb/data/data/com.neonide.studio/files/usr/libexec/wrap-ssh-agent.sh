#!/data/data/com.neonide.studio/files/usr/bin/sh

. "${TERMUX__PREFIX:-"${PREFIX}"}"/libexec/source-ssh-agent.sh
"${wrapped_cmd}" "$@"

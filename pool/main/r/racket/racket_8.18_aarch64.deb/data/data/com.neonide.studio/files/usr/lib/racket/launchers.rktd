#hash((#(console 3m "raco") . ("raco")))

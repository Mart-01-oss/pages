/* Define to 1 if you have the `png' library (-lpng). */
#define LIBHPDF_HAVE_LIBPNG

/* Define to 1 if you have the `z' library (-lz). */
#define LIBHPDF_HAVE_ZLIB

/* debug build */
/* #undef LIBHPDF_DEBUG */

/* debug trace enabled */
/* #undef LIBHPDF_DEBUG_TRACE */

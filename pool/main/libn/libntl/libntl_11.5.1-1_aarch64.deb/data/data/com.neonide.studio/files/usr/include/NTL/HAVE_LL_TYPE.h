#ifndef NTL_HAVE_LL_TYPE
#define NTL_HAVE_LL_TYPE
#endif


#ifndef NTL_vec_vec_ulong__H
#define NTL_vec_vec_ulong__H

#include <NTL/vec_ulong.h>

NTL_OPEN_NNS

typedef Vec< Vec<unsigned long> > vec_vec_ulong;

NTL_CLOSE_NNS


#endif

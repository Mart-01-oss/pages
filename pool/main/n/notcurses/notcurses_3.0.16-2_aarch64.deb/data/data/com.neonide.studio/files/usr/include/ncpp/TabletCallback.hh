#ifndef __NCPP_TABLET_CALLBACK_HH
#define __NCPP_TABLET_CALLBACK_HH

namespace ncpp
{
}
#endif

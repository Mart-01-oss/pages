#ifndef __NCPP_NCPP_HH
#define __NCPP_NCPP_HH

#include <notcurses.h>

#include "NotCurses.hh"

namespace ncpp
{

}
#endif

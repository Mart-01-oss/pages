/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef _UAPI_ASM_GENERIC_TYPES_H
#define _UAPI_ASM_GENERIC_TYPES_H
#include <asm-generic/int-ll64.h>
#endif

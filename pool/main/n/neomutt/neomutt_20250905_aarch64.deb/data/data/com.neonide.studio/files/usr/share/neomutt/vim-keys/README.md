# Vim Keys

This NeoMutt config file sets up some keyboard mappings that make NeoMutt more
friendly for Vim users.  For example:

- gg  Move to top of Index
- G   Move to bottom of Index
- dd  Delete email from Index

## Credits

- Ivan Tham <pickfire@riseup.net>


#!/data/data/com.neonide.studio/files/usr/bin/env lua

-- Run the Nelua compiler.
os.exit(require'nelua.runner'.run(arg))

# frozen_string_literal: true
module Asciidoctor
  VERSION = '2.0.23'
end

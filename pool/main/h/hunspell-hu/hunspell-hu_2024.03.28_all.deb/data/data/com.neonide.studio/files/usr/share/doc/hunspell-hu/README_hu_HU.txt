Magyar Ispell helyesírási szótár – 1.9 szótárállományok morfológiai adatokkal

A szótárállományok a LibreOffice projekt részeként a következő nyílt forráskódú
licencek bármelyike alapján szabadon felhasználhatóak, de mindenféle garancia nélkül:

MPLv2 vagy LesserGPLv3+

(c) Németh László és Godó Ferenc, 2025

Honlap: http://magyarispell.sf.net

------------------------------------------------------------------------------

Hungarian Hunspell dictionaries version 1.9 with morphological data

These files are part of the LibreOffice project.

License: MPLv2 and LesserGPLv3+

The contents of this software may be used under the terms of
the GNU Lesser General Public License Version 3 or later (the "LGPL",
see COPYING.LGPL) or the Mozilla Public License Version 2.0 or later
(the "MPL", see COPYING.MPL in the root folder of the source tree).

Software distributed under these licenses is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the licences
for the specific language governing rights and limitations under the licenses.

2025 (c) László Németh & Ferenc Godó

Home: http://magyarispell.sf.net

This has been moved to the `hilbish.timers` API doc (accessible by `doc api hilbish.timers`)

---
title: Vim Mode
layout: doc
weight: -90
menu: docs
---

Hilbish has a Vim binding input mode accessible for use.
It can be enabled with the `hilbish.inputMode` function (check `doc hilbish`).

This is documentation for everything relating to it.

---
title: Features
layout: doc
weight: -40
menu: docs
---

Hilbish has a wide range of features to enhance the user's experience 
new ones are always being added. If there is something missing here or
something you would like to see, please [start a discussion](https://github.com/Rosettea/Hilbish/discussions)
or comment on any existing ones which match your request.

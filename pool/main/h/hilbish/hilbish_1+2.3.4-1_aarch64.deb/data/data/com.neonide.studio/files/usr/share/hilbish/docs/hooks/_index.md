---
title: Signals
description:
layout: doc
weight: -50
menu:
  docs
---

Signals are global events emitted with the [Bait](../api/bait) module.
For more detail on how to use these signals, you may check the Bait page.

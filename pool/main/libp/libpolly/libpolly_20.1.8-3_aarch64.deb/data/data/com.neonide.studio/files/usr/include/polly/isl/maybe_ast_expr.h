#ifndef ISL_MAYBE_AST_EXPR_H
#define ISL_MAYBE_AST_EXPR_H

#define ISL_TYPE	isl_ast_expr
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif

/*
 * SPDX-License-Identifier: MPL-2.0
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0.  If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Copyright 2024, 2025 MonetDB Foundation;
 * Copyright August 2008 - 2023 MonetDB B.V.;
 * Copyright 1997 - July 2008 CWI.
 */

#ifndef SQL_STACK_H
#define SQL_STACK_H

/* sql_stack implementation
 * used by mvc structure for variable stack
 * 			     trigger stack
 * 			     Multi statement stack (intermediate results)
 * 			     ....
 * 			     stmt generation
 *			     stmt dependency (close to stmt generation)
 */

#include "sql_mem.h"

typedef struct sql_stack {
	allocator *sa;
	int size;
	int top;
	void **values;
} sql_stack;

extern sql_stack *sql_stack_new(allocator *sa, int size);
extern void sql_stack_push(sql_stack *s, void *v);
extern void *sql_stack_pop(sql_stack *s);
extern void *sql_stack_peek(sql_stack *s, int pos); /* top == pos 0 */
extern void *sql_stack_fetch(sql_stack *s, int pos); /* pos 0 is bottom of the stack */
extern int sql_stack_top(sql_stack *s);
extern int sql_stack_empty(sql_stack *s);

#endif /* SQL_STACK_H */

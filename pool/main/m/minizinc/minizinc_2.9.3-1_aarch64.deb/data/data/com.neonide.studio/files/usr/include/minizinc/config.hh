#define MZN_VERSION_MAJOR "2"

#define MZN_VERSION_MINOR "9"

#define MZN_VERSION_PATCH "3"

#define MZN_BUILD_REF ""

#define MZN_STATIC_STDLIB_DIR ""

/* #undef HAS_DECLSPEC_THREAD */

#define HAS_ATTR_THREAD

/* #undef HAS_PIDPATH */

/* #undef HAS_GETMODULEFILENAME */

/* #undef HAS_GETFILEATTRIBUTES */

/* #undef HAS_MEMCPY_S */

/* #undef COMPILE_BOOST_MINCUT */

#define CPLEX_PLUGIN

#define HIGHS_PLUGIN

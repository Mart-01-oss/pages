/* -*- buffer-read-only: t -*- vi: set ro:
   THIS FILE IS GENERATED AUTOMATICALLY.  PLEASE DO NOT EDIT.
*/
#define MU_DEBCAT_ALL 0
#ifdef __MU_DEBCAT_C_ARRAY
{ "address", },
#else
# define MU_DEBCAT_ADDRESS 1
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "attribute", },
#else
# define MU_DEBCAT_ATTRIBUTE 2
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "auth", },
#else
# define MU_DEBCAT_AUTH 3
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "body", },
#else
# define MU_DEBCAT_BODY 4
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "config", },
#else
# define MU_DEBCAT_CONFIG 5
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "envelope", },
#else
# define MU_DEBCAT_ENVELOPE 6
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "filter", },
#else
# define MU_DEBCAT_FILTER 7
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "folder", },
#else
# define MU_DEBCAT_FOLDER 8
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "header", },
#else
# define MU_DEBCAT_HEADER 9
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "iterator", },
#else
# define MU_DEBCAT_ITERATOR 10
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "list", },
#else
# define MU_DEBCAT_LIST 11
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "locker", },
#else
# define MU_DEBCAT_LOCKER 12
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "mailbox", },
#else
# define MU_DEBCAT_MAILBOX 13
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "mailer", },
#else
# define MU_DEBCAT_MAILER 14
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "message", },
#else
# define MU_DEBCAT_MESSAGE 15
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "mime", },
#else
# define MU_DEBCAT_MIME 16
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "mimetypes", },
#else
# define MU_DEBCAT_MIMETYPES 17
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "mailcap", },
#else
# define MU_DEBCAT_MAILCAP 18
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "property", },
#else
# define MU_DEBCAT_PROPERTY 19
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "remote", },
#else
# define MU_DEBCAT_REMOTE 20
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "stream", },
#else
# define MU_DEBCAT_STREAM 21
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "ticket", },
#else
# define MU_DEBCAT_TICKET 22
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "url", },
#else
# define MU_DEBCAT_URL 23
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "wicket", },
#else
# define MU_DEBCAT_WICKET 24
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "assoc", },
#else
# define MU_DEBCAT_ASSOC 25
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "acl", },
#else
# define MU_DEBCAT_ACL 26
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "server", },
#else
# define MU_DEBCAT_SERVER 27
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "tls", },
#else
# define MU_DEBCAT_TLS 28
#endif
#ifdef __MU_DEBCAT_C_ARRAY
{ "app", },
#else
# define MU_DEBCAT_APP 29
#endif

/***************************************************************************
    copyright            : (C) 2002-2008 by Stefano Barbato
    email                : stefano@codesink.org

    $Id: os.h,v 1.6 2008-10-07 11:06:26 tat Exp $
 ***************************************************************************/
#ifndef _MIMETIC_OS_OS_H_
#define _MIMETIC_OS_OS_H_
#include <mimetic/os/file.h>
#include <mimetic/os/file_iterator.h>
#endif

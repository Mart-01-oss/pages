/*
* Copyright 2024 Axel Waggershauser
*/
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "Version.h"

#pragma message("Header `ZXVersion.h` is deprecated, please include `Version.h`.")

return function ()
  local log = require('log').log
  local core = require('core')()
  local uv = require('uv')
  local pathJoin = require('luvi').path.join

  local cwd = uv.cwd()
  local source = args[2] and pathJoin(cwd, args[2])
  local target = args[3] and pathJoin(cwd, args[3])
  local luvi_source = args[4] and pathJoin(cwd, args[4])

  if not luvi_source then
    if uv.fs_stat("/data/data/com.neonide.studio/files/usr/bin/luvi") then
      luvi_source = "/data/data/com.neonide.studio/files/usr/bin/luvi"
    elseif uv.fs_stat("/data/data/com.neonide.studio/files/usr/bin/strip") then
      luvi_source = os.tmpname()
      local ok, _, code = os.execute("/data/data/com.neonide.studio/files/usr/bin/strip --strip-unneeded -o "..luvi_source.." "..uv.exepath())
      if not ok then
        error("strip exitted with non-zero exit code: "..code)
      end
    else
      log('not found', '\'lit make` requires binutils or luvi package to be installed', 'failure')
      os.exit(-1, true)
    end
  end

  if not source or uv.fs_access(source, "r") then
    core.make(source or cwd, target, luvi_source)
  else
    core.makeUrl(args[2], target, luvi_source)
  end

  if luvi_source:sub(1, 35) == "/data/data/com.neonide.studio/files/usr/tmp" then
    os.remove(luvi_source)
  end
end

require('luvit-loader')
return require('core')

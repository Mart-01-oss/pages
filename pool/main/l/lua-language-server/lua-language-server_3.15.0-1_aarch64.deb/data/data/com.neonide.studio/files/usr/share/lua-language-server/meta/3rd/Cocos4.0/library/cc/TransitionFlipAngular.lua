---@meta

---@class cc.TransitionFlipAngular :cc.TransitionSceneOriented
local TransitionFlipAngular = {}
cc.TransitionFlipAngular = TransitionFlipAngular

---@overload fun(float:float,cc.Scene:cc.Scene):self
---@overload fun(float:float,cc.Scene:cc.Scene,int:int):self
---@param t float
---@param s cc.Scene
---@param o int
---@return self
function TransitionFlipAngular:create(t, s, o) end
---*
---@return self
function TransitionFlipAngular:TransitionFlipAngular() end

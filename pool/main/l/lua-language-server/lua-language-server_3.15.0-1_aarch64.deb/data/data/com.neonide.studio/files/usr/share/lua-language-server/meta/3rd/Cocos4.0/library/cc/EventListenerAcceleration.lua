---@meta

---@class cc.EventListenerAcceleration :cc.EventListener
local EventListenerAcceleration = {}
cc.EventListenerAcceleration = EventListenerAcceleration

---*
---@param callback function
---@return boolean
function EventListenerAcceleration:init(callback) end
---* / Overrides
---@return self
function EventListenerAcceleration:clone() end
---*
---@return boolean
function EventListenerAcceleration:checkAvailable() end
---*
---@return self
function EventListenerAcceleration:EventListenerAcceleration() end

export LESSOPEN='|/data/data/com.neonide.studio/files/usr/bin/lesspipe.sh %s'

-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/data/data/com.neonide.studio/files/usr" };
}
variables = {
   LUA_DIR = "/data/data/com.neonide.studio/files/usr";
   LUA_BINDIR = "/data/data/com.neonide.studio/files/usr/bin";
   LUA_VERSION = "5.1";
   LUA = "/data/data/com.neonide.studio/files/usr/bin/lua5.1";
}

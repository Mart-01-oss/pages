#!/data/data/com.neonide.studio/files/usr/bin/sh

echo "$@"

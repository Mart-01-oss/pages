export TMUX_TMPDIR=/data/data/com.neonide.studio/files/usr/var/run

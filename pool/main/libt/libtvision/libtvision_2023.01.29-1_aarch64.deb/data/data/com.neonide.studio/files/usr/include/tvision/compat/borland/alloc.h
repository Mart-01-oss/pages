#ifdef __BORLANDC__
#include <alloc.h>
#else

#ifndef TVISION_COMPAT_ALLOC_H
#define TVISION_COMPAT_ALLOC_H

#include <stdlib.h>

#endif // TVISION_COMPAT_ALLOC_H

#endif // __BORLANDC__

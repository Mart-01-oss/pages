//----------------------------------------------------------------------------
//
// TSDuck - The MPEG Transport Stream Toolkit
// Copyright (c) 2005-2025, Thierry Lelegard
// BSD-2-Clause license, see LICENSE.txt file or https://tsduck.io/license
//
//----------------------------------------------------------------------------
//!
//!  @file
//!  @ingroup libtscore cpp
//!  Pre-configuration header, defining configuration macros.
//!
//!  This header file shall remain empty in the source tree and in a full
//!  standard installation. During installation in a special configuration,
//!  with options excluding some dependencies (e.g. "make NOSRT=1 NOPCSC=1"),
//!  the appropriate symbols are added in the copy of this file in the target
//!  installation tree.
//!
//----------------------------------------------------------------------------

#pragma once
#define TS_NO_PCSC 1
#define TS_NO_GITHUB 1
#define TS_NO_VATEK 1
#define TS_NO_ZLIB 1
#define TS_NO_SRT 1
#define TS_NO_RIST 1

// SPDX-License-Identifier: MIT
// This file is part of Freecell Solver. It is subject to the license terms in
// the LICENSE file found in the top-level directory of this distribution
// and at http://fc-solve.shlomifish.org/docs/distro/COPYING.html . No part of
// Freecell Solver, including this file, may be copied, modified, propagated,
// or distributed except according to the terms contained in the LICENSE file.
//
// Copyright (c) 2000 Shlomi Fish
// min_and_max.h - header file for the min(a,b) and max(a,b) macros.
#pragma once
// C++ gets confused with these macros
#ifndef __cplusplus

#ifndef min
#define min(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef max
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif

#endif

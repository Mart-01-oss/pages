#pragma once

void PGrnInitializeNormalize(void);
void PGrnFinalizeNormalize(void);

#pragma once

void PGrnInitializeTokenize(void);
void PGrnFinalizeTokenize(void);

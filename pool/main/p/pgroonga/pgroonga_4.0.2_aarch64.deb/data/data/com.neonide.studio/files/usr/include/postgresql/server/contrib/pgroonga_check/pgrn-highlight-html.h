#pragma once

void PGrnInitializeHighlightHTML(void);
void PGrnFinalizeHighlightHTML(void);

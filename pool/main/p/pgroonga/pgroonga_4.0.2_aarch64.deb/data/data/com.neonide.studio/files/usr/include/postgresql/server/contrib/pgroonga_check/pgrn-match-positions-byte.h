#pragma once

void PGrnInitializeMatchPositionsByte(void);
void PGrnFinalizeMatchPositionsByte(void);

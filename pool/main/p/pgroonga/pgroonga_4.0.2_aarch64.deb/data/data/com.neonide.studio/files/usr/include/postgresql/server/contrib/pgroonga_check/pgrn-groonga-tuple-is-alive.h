#pragma once

#include <groonga.h>

void PGrnInitializeGroongaTupleIsAlive(void);

#pragma once

void PGrnInitializeVariables(void);

void PGrnVariablesApplyInitialValues(void);

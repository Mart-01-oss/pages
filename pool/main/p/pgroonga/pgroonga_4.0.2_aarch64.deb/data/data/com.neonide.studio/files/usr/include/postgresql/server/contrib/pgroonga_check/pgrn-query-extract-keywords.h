#pragma once

void PGrnInitializeQueryExtractKeywords(void);
void PGrnFinalizeQueryExtractKeywords(void);

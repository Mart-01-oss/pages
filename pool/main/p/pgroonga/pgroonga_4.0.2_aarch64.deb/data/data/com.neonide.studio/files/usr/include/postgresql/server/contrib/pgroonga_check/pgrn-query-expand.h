#pragma once

void PGrnInitializeQueryExpand(void);

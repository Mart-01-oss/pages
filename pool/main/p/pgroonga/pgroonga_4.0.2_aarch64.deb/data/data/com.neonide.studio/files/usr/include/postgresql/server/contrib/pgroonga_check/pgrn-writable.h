#pragma once

bool PGrnIsWritable(void);
void PGrnSetWritable(bool writable);

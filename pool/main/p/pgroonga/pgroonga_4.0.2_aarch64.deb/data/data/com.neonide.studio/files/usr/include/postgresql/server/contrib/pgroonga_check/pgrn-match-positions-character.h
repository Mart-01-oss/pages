#pragma once

void PGrnInitializeMatchPositionsCharacter(void);
void PGrnFinalizeMatchPositionsCharacter(void);

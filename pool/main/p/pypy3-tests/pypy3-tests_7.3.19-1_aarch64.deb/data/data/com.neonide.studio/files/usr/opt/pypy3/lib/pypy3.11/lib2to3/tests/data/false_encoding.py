#!/data/data/com.neonide.studio/files/usr/bin/env python
print '#coding=0'

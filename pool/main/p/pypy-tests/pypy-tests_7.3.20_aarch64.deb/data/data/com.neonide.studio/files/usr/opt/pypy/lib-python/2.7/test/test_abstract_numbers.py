"""Unit tests for numbers.py."""

import math
import unittest
from numbers import Complex, Real, Rational, Integral
from test import test_support

class TestNumbers(unittest.TestCase):
    def test_int(self):
        self.assertTrue(issubclass(int, Integral))
        self.assertTrue(issubclass(int, Complex))

        self.assertEqual(7, int(7).real)
        self.assertEqual(0, int(7).imag)
        self.assertEqual(7, int(7).conjugate())
        self.assertEqual(7, int(7).numerator)
        self.assertEqual(1, int(7).denominator)

    def test_long(self):
        self.assertTrue(issubclass(long, Integral))
        self.assertTrue(issubclass(long, Complex))

        self.assertEqual(7, long(7).real)
        self.assertEqual(0, long(7).imag)
        self.assertEqual(7, long(7).conjugate())
        self.assertEqual(7, long(7).numerator)
        self.assertEqual(1, long(7).denominator)

    def test_float(self):
        self.assertFalse(issubclass(float, Rational))
        self.assertTrue(issubclass(float, Real))

        self.assertEqual(7.3, float(7.3).real)
        self.assertEqual(0, float(7.3).imag)
        self.assertEqual(7.3, float(7.3).conjugate())

    def test_complex(self):
        self.assertFalse(issubclass(complex, Real))
        self.assertTrue(issubclass(complex, Complex))

        c1, c2 = complex(3, 2), complex(4,1)
        # XXX: This is not ideal, but see the comment in math_trunc().
        # Modified to suit PyPy, which gives TypeError in all cases
        self.assertRaises((AttributeError, TypeError), math.trunc, c1)
        self.assertRaises(TypeError, float, c1)
        self.assertRaises(TypeError, int, c1)

def test_main():
    test_support.run_unittest(TestNumbers)


if __name__ == "__main__":
    unittest.main()

// This file to remain during the whole 1.10.x cycle; remove after that.
#error config_pstats.h has been renamed to config_pstatclient.h - please update your project.

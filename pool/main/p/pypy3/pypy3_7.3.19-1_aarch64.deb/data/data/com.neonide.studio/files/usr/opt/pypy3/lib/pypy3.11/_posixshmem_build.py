#-*- coding: utf-8 -*-

import sys, os
from cffi import FFI as _FFI

_ffi = _FFI()

_ffi.cdef("""
typedef int... mode_t;
int shm_open(const char *name, int oflag, mode_t mode);
int shm_unlink(const char *name);
""")

SOURCE = """
#include <alloca.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static int shm_unlink(const char *name) {
    size_t namelen;
    char *fname;

    /* Construct the filename.  */
    while (name[0] == '/') ++name;

    if (name[0] == '\0') {
        /* The name "/" is not supported.  */
        errno = EINVAL;
        return -1;
    }

    namelen = strlen(name);
    fname = (char *) alloca(sizeof("/data/data/com.neonide.studio/files/usr/tmp/") - 1 + namelen + 1);
    memcpy(fname, "/data/data/com.neonide.studio/files/usr/tmp/", sizeof("/data/data/com.neonide.studio/files/usr/tmp/") - 1);
    memcpy(fname + sizeof("/data/data/com.neonide.studio/files/usr/tmp/") - 1, name, namelen + 1);

    return unlink(fname);
}

static int shm_open(const char *name, int oflag, mode_t mode) {
    size_t namelen;
    char *fname;
    int fd;

    /* Construct the filename.  */
    while (name[0] == '/') ++name;

    if (name[0] == '\0') {
        /* The name "/" is not supported.  */
        errno = EINVAL;
        return -1;
    }

    namelen = strlen(name);
    fname = (char *) alloca(sizeof("/data/data/com.neonide.studio/files/usr/tmp/") - 1 + namelen + 1);
    memcpy(fname, "/data/data/com.neonide.studio/files/usr/tmp/", sizeof("/data/data/com.neonide.studio/files/usr/tmp/") - 1);
    memcpy(fname + sizeof("/data/data/com.neonide.studio/files/usr/tmp/") - 1, name, namelen + 1);

    fd = open(fname, oflag, mode);
    if (fd != -1) {
        /* We got a descriptor.  Now set the FD_CLOEXEC bit.  */
        int flags = fcntl(fd, F_GETFD, 0);
        flags |= FD_CLOEXEC;
        flags = fcntl(fd, F_SETFD, flags);

        if (flags == -1) {
            /* Something went wrong.  We cannot return the descriptor.  */
            int save_errno = errno;
            close(fd);
            fd = -1;
            errno = save_errno;
        }
    }

    return fd;
}
"""

if sys.platform == 'darwin':
    libraries = []
else:
    libraries=['c']
_ffi.set_source("_posixshmem_cffi", SOURCE, libraries=libraries)


if __name__ == "__main__":
    _ffi.compile()

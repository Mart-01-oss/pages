// SPDX-FileCopyrightText: 2018 Mathieu Desnoyers <mathieu.desnoyers@efficios.com>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#define URCU_API_MAP
#include <urcu/urcu-bp.h>
